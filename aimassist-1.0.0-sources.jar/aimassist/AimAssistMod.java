package aimassist;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.fabricmc.fabric.api.client.screen.v1.Screens;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_124;
import net.minecraft.class_1268;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_315;
import net.minecraft.class_332;
import net.minecraft.class_3532;
import net.minecraft.class_357;
import net.minecraft.class_3675;
import net.minecraft.class_3966;
import net.minecraft.class_4185;
import net.minecraft.class_429;
import net.minecraft.class_437;
import org.lwjgl.glfw.GLFW;

import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import java.util.function.BooleanSupplier;

public class AimAssistMod implements ClientModInitializer {

    // ===== Бой =====
    static boolean killEnabled = false;      // килаура
    static boolean aimEnabled = false;       // наводка
    static boolean triggerEnabled = false;   // триггербот
    static double range = 6.0;               // дальность наводки
    static double fov = 90.0;                // угол наводки
    static double smooth = 0.25;             // скорость наводки
    static double killRange = 3.5;           // дальность килауры
    static boolean killNeedFov = false;

    // ===== Движение =====
    static boolean sprintEnabled = false;
    static boolean flyEnabled = false;
    static boolean speedEnabled = false;
    static boolean bhopEnabled = false;
    static boolean spiderEnabled = false;
    static boolean highJumpEnabled = false;
    static double flySpeed = 0.5;            // 0.1 .. 1.5
    static double speedMul = 1.5;            // 1.0 .. 3.0

    // ===== Игрок =====
    static boolean autoWalkEnabled = false;
    static boolean antiAfkEnabled = false;

    // ===== Визуалы =====
    static boolean nvEnabled = false;
    static boolean zoomEnabled = false;
    static boolean wideEnabled = false;

    // ===== Разное =====
    static boolean debugEnabled = false;
    static boolean targetPlayers = true;
    static boolean targetMobs = true;

    static class_304 menuKey;
    static final Path CONFIG = FabricLoader.getInstance().getConfigDir().resolve("aimassist.properties");

    static int dbgTick = 0;
    static int afkTick = 0;
    static boolean nvApplied = false;
    static boolean fovSaved = false;
    static boolean walkApplied = false;
    static Integer origFov = null;

    @Override
    public void onInitializeClient() {
        load();

        class_304.class_11900 category = class_304.class_11900.method_74698(class_2960.method_60655("aimassist", "main"));
        menuKey = KeyBindingHelper.registerKeyBinding(new class_304(
                "Меню читов", class_3675.class_307.field_1668, GLFW.GLFW_KEY_RIGHT_SHIFT, category));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (menuKey.method_1436()) {
                if (client.field_1755 == null && client.field_1724 != null) {
                    client.method_1507(new MenuScreen());
                }
            }

            if (client.field_1724 == null || client.field_1687 == null) return;

            always(client);

            if (client.field_1755 == null) {
                if (aimEnabled) aim(client);
                if (killEnabled) killAura(client);
                if (triggerEnabled) trigger(client);
                movement(client);
            }
        });

        // Кнопка "Секретные настройки" в меню настроек
        ScreenEvents.AFTER_INIT.register((client, screen, w, h) -> {
            if (screen instanceof class_429) {
                class_4185 btn = class_4185.method_46430(class_2561.method_43470("Секретные настройки"),
                                b -> client.method_1507(new SecretScreen(screen)))
                        .method_46434(5, 5, 140, 20).method_46431();
                Screens.getButtons(screen).add(btn);
            }
        });
    }

    private static void msg(class_310 client, String text) {
        if (client.field_1724 != null) client.field_1724.method_7353(class_2561.method_43470(text), true);
    }

    // ===== Всегда активное (визуалы, авто-ходьба) =====
    private static void always(class_310 client) {
        class_1657 me = client.field_1724;
        class_315 o = client.field_1690;

        if (nvEnabled) {
            me.method_6092(new class_1293(class_1294.field_5925, 400, 0, false, false));
            nvApplied = true;
        } else if (nvApplied) {
            me.method_6016(class_1294.field_5925);
            nvApplied = false;
        }

        var fovOpt = o.method_41808();
        if (zoomEnabled || wideEnabled) {
            if (!fovSaved) { origFov = fovOpt.method_41753(); fovSaved = true; }
            fovOpt.method_41748(zoomEnabled ? 30 : 110);
        } else if (fovSaved) {
            if (origFov != null) fovOpt.method_41748(origFov);
            fovSaved = false;
        }

        if (autoWalkEnabled) {
            o.field_1894.method_23481(true);
            walkApplied = true;
        } else if (walkApplied) {
            o.field_1894.method_23481(false);
            walkApplied = false;
        }
    }

    // ===== Движение =====
    private static double[] moveDir(class_315 o, class_1657 me) {
        double f = (o.field_1894.method_1434() ? 1 : 0) - (o.field_1881.method_1434() ? 1 : 0);
        double s = (o.field_1913.method_1434() ? 1 : 0) - (o.field_1849.method_1434() ? 1 : 0);
        if (f == 0 && s == 0) return null;
        double yaw = Math.toRadians(me.method_36454());
        double dx = -Math.sin(yaw) * f + Math.cos(yaw) * s;
        double dz = Math.cos(yaw) * f + Math.sin(yaw) * s;
        double len = Math.hypot(dx, dz);
        if (len < 1e-6) return null;
        return new double[]{dx / len, dz / len};
    }

    private static void movement(class_310 client) {
        class_1657 me = client.field_1724;
        class_315 o = client.field_1690;
        if (me.method_7325()) return;

        if (sprintEnabled && o.field_1894.method_1434() && !me.method_5715()
                && !me.field_5976 && me.method_7344().method_7586() > 6) {
            me.method_5728(true);
        }

        if (antiAfkEnabled && ++afkTick >= 600) {
            afkTick = 0;
            me.method_6104(class_1268.field_5808);
            if (me.method_24828()) {
                class_243 vv = me.method_18798();
                me.method_18800(vv.field_1352, 0.42, vv.field_1350);
            }
        }

        class_243 v = me.method_18798();

        if (flyEnabled) {
            double vy = 0;
            if (o.field_1903.method_1434()) vy += flySpeed;
            if (o.field_1832.method_1434()) vy -= flySpeed;
            double vx = 0, vz = 0;
            double[] d = moveDir(o, me);
            if (d != null) { vx = d[0] * flySpeed; vz = d[1] * flySpeed; }
            me.method_18800(vx, vy, vz);
            return;
        }

        if (spiderEnabled && me.field_5976 && o.field_1894.method_1434()) {
            me.method_18800(v.field_1352, 0.2, v.field_1350);
            v = me.method_18798();
        }

        if (highJumpEnabled && o.field_1903.method_1434() && me.method_24828()) {
            me.method_18800(v.field_1352, 0.8, v.field_1350);
            v = me.method_18798();
        }

        double[] d = moveDir(o, me);
        if (d == null) return;

        if (speedEnabled) {
            double target = 0.215 * speedMul;
            me.method_18800(d[0] * target, v.field_1351, d[1] * target);
            v = me.method_18798();
        }

        if (bhopEnabled && me.method_24828()) {
            me.method_18800(v.field_1352, 0.42, v.field_1350);
        }
    }

    // ===== Выбор цели =====
    private static boolean validTarget(class_1657 me, class_1297 e) {
        if (e == me || !(e instanceof class_1309 le) || !le.method_5805()) return false;
        boolean isPlayer = e instanceof class_1657;
        if (isPlayer && !targetPlayers) return false;
        if (!isPlayer && !targetMobs) return false;
        return true;
    }

    private static List<class_1297> nearby(class_310 client, double radius) {
        class_1657 me = client.field_1724;
        List<class_1297> res = new ArrayList<>();
        for (class_1297 e : client.field_1687.method_8335(me, me.method_5829().method_1014(radius))) {
            if (validTarget(me, e) && me.method_5739(e) <= radius) res.add(e);
        }
        return res;
    }

    private static void debug(class_310 client, String name, int count, double radius) {
        if (!debugEnabled) return;
        if (++dbgTick % 40 != 0) return;
        msg(client, name + ": целей в радиусе " + String.format("%.1f", radius) + " бл. = " + count);
    }

    // ===== Наводка =====
    private static void aim(class_310 client) {
        class_1657 me = client.field_1724;
        if (me.method_7325()) return;
        class_1297 best = null;
        double bestAngle = Double.MAX_VALUE;

        List<class_1297> list = nearby(client, range);
        debug(client, "Наводка", list.size(), range);
        for (class_1297 e : list) {
            float[] rot = rotationTo(me, e);
            double dy = Math.abs(class_3532.method_15393(rot[0] - me.method_36454()));
            double dp = Math.abs(rot[1] - me.method_36455());
            double angle = Math.hypot(dy, dp);
            if (dy > fov / 2.0) continue;
            if (angle < bestAngle) { bestAngle = angle; best = e; }
        }

        if (best == null) return;
        float[] rot = rotationTo(me, best);
        float dYaw = class_3532.method_15393(rot[0] - me.method_36454());
        float dPitch = rot[1] - me.method_36455();
        me.method_36456(me.method_36454() + (float) (dYaw * smooth));
        me.method_36457(class_3532.method_15363(me.method_36455() + (float) (dPitch * smooth), -90f, 90f));
    }

    // ===== Килаура =====
    private static void killAura(class_310 client) {
        class_1657 me = client.field_1724;
        if (client.field_1761 == null || me.method_7325()) return;
        if (me.method_7261(0.5f) < 0.95f) return;

        class_1297 best = null;
        double bestDist = Double.MAX_VALUE;

        List<class_1297> list = nearby(client, killRange);
        debug(client, "Килаура", list.size(), killRange);
        for (class_1297 e : list) {
            double d = me.method_5739(e);
            if (killNeedFov) {
                float[] rot = rotationTo(me, e);
                if (Math.abs(class_3532.method_15393(rot[0] - me.method_36454())) > 60) continue;
            }
            if (d < bestDist) { bestDist = d; best = e; }
        }

        if (best == null) return;
        client.field_1761.method_2918(me, best);
        me.method_6104(class_1268.field_5808);
    }

    // ===== Триггербот: бьёт, когда прицел на цели =====
    private static void trigger(class_310 client) {
        class_1657 me = client.field_1724;
        if (client.field_1761 == null || me.method_7325()) return;
        if (me.method_7261(0.5f) < 0.95f) return;
        class_239 h = client.field_1765;
        if (h != null && h.method_17783() == class_239.class_240.field_1331 && h instanceof class_3966 ehr) {
            class_1297 e = ehr.method_17782();
            if (validTarget(me, e)) {
                client.field_1761.method_2918(me, e);
                me.method_6104(class_1268.field_5808);
            }
        }
    }

    private static float[] rotationTo(class_1657 me, class_1297 t) {
        double dx = t.method_23317() - me.method_23317();
        double dy = (t.method_23318() + t.method_17682() * 0.7) - me.method_23320();
        double dz = t.method_23321() - me.method_23321();
        double flat = Math.sqrt(dx * dx + dz * dz);
        float yaw = (float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0);
        float pitch = (float) -Math.toDegrees(Math.atan2(dy, flat));
        return new float[]{yaw, pitch};
    }

    // ===== Сохранение / загрузка =====
    static void save() {
        try (OutputStream out = Files.newOutputStream(CONFIG)) {
            Properties p = new Properties();
            p.setProperty("range", String.valueOf(range));
            p.setProperty("fov", String.valueOf(fov));
            p.setProperty("smooth", String.valueOf(smooth));
            p.setProperty("players", String.valueOf(targetPlayers));
            p.setProperty("mobs", String.valueOf(targetMobs));
            p.setProperty("killRange", String.valueOf(killRange));
            p.setProperty("killNeedFov", String.valueOf(killNeedFov));
            p.setProperty("flySpeed", String.valueOf(flySpeed));
            p.setProperty("speedMul", String.valueOf(speedMul));
            p.store(out, "AimAssist");
        } catch (Exception ignored) {}
    }

    static void load() {
        if (!Files.exists(CONFIG)) return;
        try (InputStream in = Files.newInputStream(CONFIG)) {
            Properties p = new Properties();
            p.load(in);
            range = Double.parseDouble(p.getProperty("range", "6.0"));
            fov = Double.parseDouble(p.getProperty("fov", "90.0"));
            smooth = Double.parseDouble(p.getProperty("smooth", "0.25"));
            targetPlayers = Boolean.parseBoolean(p.getProperty("players", "true"));
            targetMobs = Boolean.parseBoolean(p.getProperty("mobs", "true"));
            killRange = Double.parseDouble(p.getProperty("killRange", "3.5"));
            killNeedFov = Boolean.parseBoolean(p.getProperty("killNeedFov", "false"));
            flySpeed = Double.parseDouble(p.getProperty("flySpeed", "0.5"));
            speedMul = Double.parseDouble(p.getProperty("speedMul", "1.5"));
        } catch (Exception ignored) {}
    }

    static class_2561 label(String name, boolean on) {
        return class_2561.method_43470(name + ": " + (on ? "ВКЛ" : "ВЫКЛ"));
    }

    static class_2561 modLabel(String name, boolean on) {
        return class_2561.method_43470(name).method_27692(on ? class_124.field_1060 : class_124.field_1068);
    }

    static class_4185 toggle(int x, int y, int w, String name, BooleanSupplier get, Runnable flip) {
        return class_4185.method_46430(label(name, get.getAsBoolean()), b -> {
            flip.run();
            b.method_25355(label(name, get.getAsBoolean()));
        }).method_46434(x, y, w, 20).method_46431();
    }

    // ===== Меню в стиле ClickGUI (Правый Shift) =====
    static class MenuScreen extends class_437 {
        private static final String[] TITLES = {"Бой", "Движение", "Игрок", "Визуалы", "Разное"};
        private final int[] counts = new int[5];
        private int colW;
        private int x0;

        MenuScreen() {
            super(class_2561.method_43470("Меню"));
        }

        private int colX(int col) { return x0 + col * (colW + 6); }

        private void mod(int col, String name, BooleanSupplier get, Runnable flip) {
            int x = colX(col);
            int y = 32 + counts[col] * 16;
            counts[col]++;
            method_37063(class_4185.method_46430(modLabel(name, get.getAsBoolean()), b -> {
                flip.run();
                b.method_25355(modLabel(name, get.getAsBoolean()));
            }).method_46434(x, y, colW, 14).method_46431());
        }

        private void action(int col, String name, Runnable run) {
            int x = colX(col);
            int y = 32 + counts[col] * 16;
            counts[col]++;
            method_37063(class_4185.method_46430(class_2561.method_43470(name).method_27692(class_124.field_1054), b -> run.run())
                    .method_46434(x, y, colW, 14).method_46431());
        }

        @Override
        protected void method_25426() {
            for (int i = 0; i < counts.length; i++) counts[i] = 0;
            colW = Math.max(70, Math.min(110, (field_22789 - 30) / 5 - 6));
            x0 = (field_22789 - (5 * (colW + 6) - 6)) / 2;

            // Бой
            mod(0, "Килаура", () -> killEnabled, () -> killEnabled = !killEnabled);
            mod(0, "Наводка", () -> aimEnabled, () -> aimEnabled = !aimEnabled);
            mod(0, "Триггербот", () -> triggerEnabled, () -> triggerEnabled = !triggerEnabled);

            // Движение
            mod(1, "Спринт", () -> sprintEnabled, () -> sprintEnabled = !sprintEnabled);
            mod(1, "Полёт", () -> flyEnabled, () -> flyEnabled = !flyEnabled);
            mod(1, "Скорость", () -> speedEnabled, () -> speedEnabled = !speedEnabled);
            mod(1, "Авто-прыжок", () -> bhopEnabled, () -> bhopEnabled = !bhopEnabled);
            mod(1, "Паук", () -> spiderEnabled, () -> spiderEnabled = !spiderEnabled);
            mod(1, "Выс. прыжок", () -> highJumpEnabled, () -> highJumpEnabled = !highJumpEnabled);

            // Игрок
            mod(2, "Авто-ходьба", () -> autoWalkEnabled, () -> autoWalkEnabled = !autoWalkEnabled);
            mod(2, "Анти-АФК", () -> antiAfkEnabled, () -> antiAfkEnabled = !antiAfkEnabled);

            // Визуалы
            mod(3, "Ночн. зрение", () -> nvEnabled, () -> nvEnabled = !nvEnabled);
            mod(3, "Зум", () -> zoomEnabled, () -> zoomEnabled = !zoomEnabled);
            mod(3, "Широкий FOV", () -> wideEnabled, () -> wideEnabled = !wideEnabled);

            // Разное
            mod(4, "Отладка целей", () -> debugEnabled, () -> debugEnabled = !debugEnabled);
            action(4, "Настройки", () -> field_22787.method_1507(new SecretScreen(this)));
            action(4, "Закрыть", this::method_25419);
        }

        @Override
        public void method_25394(class_332 ctx, int mouseX, int mouseY, float delta) {
            for (int c = 0; c < 5; c++) {
                int x = colX(c);
                int bottom = 32 + counts[c] * 16 + 2;
                ctx.method_25294(x - 2, 14, x + colW + 2, bottom, 0xB0101018);   // панель
                ctx.method_25294(x - 2, 14, x + colW + 2, 29, 0xE0202838);       // заголовок
            }
            super.method_25394(ctx, mouseX, mouseY, delta);
            for (int c = 0; c < 5; c++) {
                ctx.method_27534(field_22793, class_2561.method_43470(TITLES[c]), colX(c) + colW / 2, 18, 0xFFFFFF);
            }
        }

        @Override
        public void method_25419() {
            save();
            field_22787.method_1507(null);
        }
    }

    // ===== Экран настроек (значения) =====
    static class SecretScreen extends class_437 {
        private final class_437 parent;

        SecretScreen(class_437 parent) {
            super(class_2561.method_43470("Секретные настройки"));
            this.parent = parent;
        }

        @Override
        protected void method_25426() {
            int left = field_22789 / 2 - 205;
            int right = field_22789 / 2 + 5;
            int y = 36;
            int step = 24;

            method_37063(new class_357(left, y, 200, 20, class_2561.method_43473(), (range - 2) / 10.0) {
                { method_25346(); }
                @Override protected void method_25346() {
                    method_25355(class_2561.method_43470("Дальность наводки: " + String.format("%.1f", 2 + field_22753 * 10) + " бл."));
                }
                @Override protected void method_25344() { range = 2 + field_22753 * 10; }
            });

            method_37063(new class_357(left, y + step, 200, 20, class_2561.method_43473(), (fov - 10) / 170.0) {
                { method_25346(); }
                @Override protected void method_25346() {
                    method_25355(class_2561.method_43470("Угол наводки: " + (int) (10 + field_22753 * 170) + "°"));
                }
                @Override protected void method_25344() { fov = 10 + field_22753 * 170; }
            });

            method_37063(new class_357(left, y + step * 2, 200, 20, class_2561.method_43473(), (smooth - 0.05) / 0.95) {
                { method_25346(); }
                @Override protected void method_25346() {
                    method_25355(class_2561.method_43470("Скорость наводки: " + (int) ((0.05 + field_22753 * 0.95) * 100) + "%"));
                }
                @Override protected void method_25344() { smooth = 0.05 + field_22753 * 0.95; }
            });

            method_37063(new class_357(left, y + step * 3, 200, 20, class_2561.method_43473(), (killRange - 2) / 4.0) {
                { method_25346(); }
                @Override protected void method_25346() {
                    method_25355(class_2561.method_43470("Дальность килауры: " + String.format("%.1f", 2 + field_22753 * 4) + " бл."));
                }
                @Override protected void method_25344() { killRange = 2 + field_22753 * 4; }
            });

            method_37063(new class_357(left, y + step * 4, 200, 20, class_2561.method_43473(), (flySpeed - 0.1) / 1.4) {
                { method_25346(); }
                @Override protected void method_25346() {
                    method_25355(class_2561.method_43470("Скорость полёта: " + String.format("%.1f", 0.1 + field_22753 * 1.4)));
                }
                @Override protected void method_25344() { flySpeed = 0.1 + field_22753 * 1.4; }
            });

            method_37063(new class_357(left, y + step * 5, 200, 20, class_2561.method_43473(), (speedMul - 1.0) / 2.0) {
                { method_25346(); }
                @Override protected void method_25346() {
                    method_25355(class_2561.method_43470("Множитель скорости: x" + String.format("%.1f", 1.0 + field_22753 * 2.0)));
                }
                @Override protected void method_25344() { speedMul = 1.0 + field_22753 * 2.0; }
            });

            method_37063(toggle(right, y, 200, "Килаура только вперёд", () -> killNeedFov, () -> killNeedFov = !killNeedFov));
            method_37063(toggle(right, y + step, 200, "Цели: игроки", () -> targetPlayers, () -> targetPlayers = !targetPlayers));
            method_37063(toggle(right, y + step * 2, 200, "Цели: мобы", () -> targetMobs, () -> targetMobs = !targetMobs));

            method_37063(class_4185.method_46430(class_2561.method_43470("Готово"), b -> method_25419())
                    .method_46434(right, y + step * 5, 200, 20).method_46431());
        }

        @Override
        public void method_25394(class_332 ctx, int mouseX, int mouseY, float delta) {
            super.method_25394(ctx, mouseX, mouseY, delta);
            ctx.method_27534(field_22793, field_22785, field_22789 / 2, 14, 0xFFFFFF);
        }

        @Override
        public void method_25419() {
            save();
            field_22787.method_1507(parent);
        }
    }
}
