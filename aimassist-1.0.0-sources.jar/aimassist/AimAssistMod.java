package aimassist;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.fabricmc.fabric.api.client.screen.v1.Screens;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_3532;
import net.minecraft.class_357;
import net.minecraft.class_3675;
import net.minecraft.class_4185;
import net.minecraft.class_429;
import net.minecraft.class_437;
import org.lwjgl.glfw.GLFW;

import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;

public class AimAssistMod implements ClientModInitializer {

    // ===== Настройки =====
    static boolean enabled = false;
    static double range = 6.0;        // дальность, блоки
    static double fov = 90.0;         // угол обзора, градусы
    static double smooth = 0.25;      // плавность 0.05..1.0 (1 = мгновенно)
    static boolean targetPlayers = true;
    static boolean targetMobs = true;

    static class_304 toggleKey;
    static final Path CONFIG = FabricLoader.getInstance().getConfigDir().resolve("aimassist.properties");

    @Override
    public void onInitializeClient() {
        load();

        class_304.class_11900 category = class_304.class_11900.method_74698(class_2960.method_60655("aimassist", "main"));
        toggleKey = KeyBindingHelper.registerKeyBinding(new class_304(
                "Помощь в прицеливании", class_3675.class_307.field_1668, GLFW.GLFW_KEY_Z, category));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (toggleKey.method_1436()) {
                enabled = !enabled;
                if (client.field_1724 != null) {
                    client.field_1724.method_7353(class_2561.method_43470("Помощь в прицеливании: " + (enabled ? "ВКЛ" : "ВЫКЛ")), true);
                }
            }
            if (enabled && client.field_1724 != null && client.field_1687 != null && client.field_1755 == null) {
                aim(client);
            }
        });

        // Кнопка "Секретные настройки" в меню настроек
        ScreenEvents.AFTER_INIT.register((client, screen, w, h) -> {
            if (screen instanceof class_429) {
                class_4185 btn = class_4185.method_46430(class_2561.method_43470("Секретные настройки"),
                                b -> client.method_1507(new SecretScreen(screen)))
                        .method_46434(5, 5, 140, 20).method_46431();
                Screens.getButtons(screen).add(btn);
            }
        });
    }

    // ===== Логика наведения =====
    private static void aim(class_310 client) {
        class_1657 me = client.field_1724;
        class_1297 best = null;
        double bestAngle = Double.MAX_VALUE;

        for (class_1297 e : client.field_1687.method_18112()) {
            if (e == me || !(e instanceof class_1309 le) || !le.method_5805()) continue;
            boolean isPlayer = e instanceof class_1657;
            if (isPlayer && !targetPlayers) continue;
            if (!isPlayer && !targetMobs) continue;
            if (me.method_5739(e) > range) continue;

            float[] rot = rotationTo(me, e);
            double dy = Math.abs(class_3532.method_15393(rot[0] - me.method_36454()));
            double dp = Math.abs(rot[1] - me.method_36455());
            double angle = Math.hypot(dy, dp);
            if (dy > fov / 2.0) continue;
            if (angle < bestAngle) { bestAngle = angle; best = e; }
        }

        if (best == null) return;
        float[] rot = rotationTo(me, best);
        float dYaw = class_3532.method_15393(rot[0] - me.method_36454());
        float dPitch = rot[1] - me.method_36455();
        me.method_36456(me.method_36454() + (float) (dYaw * smooth));
        me.method_36457(class_3532.method_15363(me.method_36455() + (float) (dPitch * smooth), -90f, 90f));
    }

    private static float[] rotationTo(class_1657 me, class_1297 t) {
        double dx = t.method_23317() - me.method_23317();
        double dy = (t.method_23318() + t.method_17682() * 0.7) - me.method_23320();
        double dz = t.method_23321() - me.method_23321();
        double flat = Math.sqrt(dx * dx + dz * dz);
        float yaw = (float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0);
        float pitch = (float) -Math.toDegrees(Math.atan2(dy, flat));
        return new float[]{yaw, pitch};
    }

    // ===== Сохранение / загрузка =====
    static void save() {
        try (OutputStream out = Files.newOutputStream(CONFIG)) {
            Properties p = new Properties();
            p.setProperty("range", String.valueOf(range));
            p.setProperty("fov", String.valueOf(fov));
            p.setProperty("smooth", String.valueOf(smooth));
            p.setProperty("players", String.valueOf(targetPlayers));
            p.setProperty("mobs", String.valueOf(targetMobs));
            p.store(out, "AimAssist");
        } catch (Exception ignored) {}
    }

    static void load() {
        if (!Files.exists(CONFIG)) return;
        try (InputStream in = Files.newInputStream(CONFIG)) {
            Properties p = new Properties();
            p.load(in);
            range = Double.parseDouble(p.getProperty("range", "6.0"));
            fov = Double.parseDouble(p.getProperty("fov", "90.0"));
            smooth = Double.parseDouble(p.getProperty("smooth", "0.25"));
            targetPlayers = Boolean.parseBoolean(p.getProperty("players", "true"));
            targetMobs = Boolean.parseBoolean(p.getProperty("mobs", "true"));
        } catch (Exception ignored) {}
    }

    // ===== Экран секретных настроек =====
    static class SecretScreen extends class_437 {
        private final class_437 parent;

        SecretScreen(class_437 parent) {
            super(class_2561.method_43470("Секретные настройки"));
            this.parent = parent;
        }

        @Override
        protected void method_25426() {
            int cx = field_22789 / 2 - 100;
            int y = field_22790 / 4;

            method_37063(new class_357(cx, y, 200, 20, class_2561.method_43473(), (range - 2) / 10.0) {
                { method_25346(); }
                @Override protected void method_25346() {
                    method_25355(class_2561.method_43470("Дальность: " + String.format("%.1f", 2 + field_22753 * 10) + " бл."));
                }
                @Override protected void method_25344() { range = 2 + field_22753 * 10; }
            });

            method_37063(new class_357(cx, y + 24, 200, 20, class_2561.method_43473(), (fov - 10) / 170.0) {
                { method_25346(); }
                @Override protected void method_25346() {
                    method_25355(class_2561.method_43470("Угол обзора: " + (int) (10 + field_22753 * 170) + "°"));
                }
                @Override protected void method_25344() { fov = 10 + field_22753 * 170; }
            });

            method_37063(new class_357(cx, y + 48, 200, 20, class_2561.method_43473(), (smooth - 0.05) / 0.95) {
                { method_25346(); }
                @Override protected void method_25346() {
                    method_25355(class_2561.method_43470("Скорость наводки: " + (int) ((0.05 + field_22753 * 0.95) * 100) + "%"));
                }
                @Override protected void method_25344() { smooth = 0.05 + field_22753 * 0.95; }
            });

            method_37063(class_4185.method_46430(label("Игроки", targetPlayers), b -> {
                targetPlayers = !targetPlayers;
                b.method_25355(label("Игроки", targetPlayers));
            }).method_46434(cx, y + 76, 200, 20).method_46431());

            method_37063(class_4185.method_46430(label("Мобы", targetMobs), b -> {
                targetMobs = !targetMobs;
                b.method_25355(label("Мобы", targetMobs));
            }).method_46434(cx, y + 100, 200, 20).method_46431());

            method_37063(class_4185.method_46430(class_2561.method_43470("Готово"), b -> method_25419())
                    .method_46434(cx, y + 130, 200, 20).method_46431());
        }

        private static class_2561 label(String name, boolean on) {
            return class_2561.method_43470(name + ": " + (on ? "ВКЛ" : "ВЫКЛ"));
        }

        @Override
        public void method_25394(class_332 ctx, int mouseX, int mouseY, float delta) {
            super.method_25394(ctx, mouseX, mouseY, delta);
            ctx.method_27534(field_22793, field_22785, field_22789 / 2, 20, 0xFFFFFF);
        }

        @Override
        public void method_25419() {
            save();
            field_22787.method_1507(parent);
        }
    }
}
